 class SpellGame {
	public static void main(String[] args) {
		// initialize the frame and set it to visible
		GameFrame game = new GameFrame();
		game.pack();
		game.setVisible(true);
	}
}
